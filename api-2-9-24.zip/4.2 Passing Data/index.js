import express from "express";

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res, next) => {
  res.render("index.ejs");
});

app.post("/submit", (req, res, next) => {
  res.render("index.ejs", {
    numberOfLetters: req.body.fName.length + req.body.lName.length,
  });
});

app.listen(port, () => {
  console.log("Server Listening on port " + port);
});
